# Estoque App — versão oficial

Este repositório contém a versão oficial do aplicativo de estoque, preparada para publicação e manutenção por Git.

## Estrutura de hospedagem recomendada

- **GitHub:** fonte oficial do código e histórico das versões.
- **Netlify:** hospedagem principal.
- **Cloudflare Pages ou outro host estático:** plano B para publicação do mesmo projeto.
- **Domínio próprio:** recomendado para que o endereço usado pelo APK não dependa diretamente do provedor de hospedagem.

## Arquivos importantes

- `index.html` — aplicativo principal.
- `sw.js` — Service Worker, responsável pelo funcionamento offline e pelo cache dos recursos.
- `manifest.json` — configuração do aplicativo web.
- `icon-*.png` — ícones do aplicativo.
- `_redirects` — regras de redirecionamento utilizadas pela hospedagem Netlify.
- `assetlinks-real.json` — arquivo relacionado à integração do aplicativo Android.

## Publicação

O projeto é um site estático: os arquivos desta pasta devem ser publicados como estão, sem etapa de build obrigatória.

### Netlify

Conecte este repositório ao Netlify e configure o diretório de publicação como a raiz do projeto.

### Plano B

Publique a mesma raiz do projeto em um serviço compatível com hospedagem de sites estáticos. O objetivo é manter uma segunda publicação pronta para uso.

## Atualizando o aplicativo

Ao alterar o aplicativo:

1. Faça a alteração no projeto.
2. Teste localmente.
3. Faça commit da alteração no Git.
4. Envie (`push`) para o GitHub.
5. Verifique o deploy no Netlify.
6. Teste o aplicativo novamente.

### Cache / Service Worker

O `sw.js` usa uma versão de cache identificada por `CACHE_NAME`.

Quando uma alteração importante nos arquivos estáticos precisar obrigatoriamente substituir o cache antigo, aumente a versão, por exemplo:

`estoque-app-v5` → `estoque-app-v6`

O Service Worker desta versão já utiliza `skipWaiting()` e `clients.claim()` para acelerar a ativação da nova versão.

## Backup

Mantenha também uma cópia ZIP do projeto fora do GitHub. O GitHub deve ser tratado como a fonte oficial do código, mas uma segunda cópia independente protege contra perda de acesso à conta.

## Dados do aplicativo

O código do aplicativo e os dados utilizados no dispositivo são coisas diferentes. Antes de migrar o endereço do aplicativo ou fazer alterações importantes, faça os testes de exportação/importação de dados disponíveis no próprio aplicativo.

## Regra importante

Não coloque senhas, tokens privados, chaves secretas ou outros segredos no repositório.

---
Versão preparada para GitHub a partir de `site-para-netlify-atualizado-cache-seguro.zip`.
