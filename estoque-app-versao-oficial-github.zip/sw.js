// Service Worker - permite que o app funcione offline e reduz requisicoes desnecessarias.
//
// IMPORTANTE: quando uma nova versao do aplicativo for publicada, altere a
// versao abaixo (ex.: v5 -> v6). O novo Service Worker cria um cache novo,
// recebe os arquivos atuais do Netlify e remove o cache antigo ao ativar.
const CACHE_NAME = 'estoque-app-v5';

const ARQUIVOS_PARA_CACHE = [
    './',
    './index.html',
    './manifest.json',
    './icon-192.png',
    './icon-512.png',
    './icon-512-maskable.png',
    'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js',
    'https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.31/jspdf.plugin.autotable.min.js',
    'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js'
];

// Instala a nova versao e baixa a versao atual dos arquivos.
self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then((cache) => cache.addAll(ARQUIVOS_PARA_CACHE))
            .then(() => self.skipWaiting())
    );
});

// Quando a nova versao ativa, remove os caches de versoes anteriores.
self.addEventListener('activate', (event) => {
    event.waitUntil(
        caches.keys().then((nomes) => Promise.all(
            nomes
                .filter((nome) => nome !== CACHE_NAME)
                .map((nome) => caches.delete(nome))
        )).then(() => self.clients.claim())
    );
});

// Cache First para os recursos estaticos do aplicativo:
// se o arquivo ja estiver no aparelho, ele e entregue localmente sem nova
// requisicao ao Netlify. Se ainda nao estiver no cache, baixa e guarda.
//
// Para requisicoes que nao sao estaticas (por exemplo, APIs/dados externos),
// mantemos comportamento de rede com fallback para cache, evitando guardar
// respostas dinamicas como se fossem arquivos estaticos.
self.addEventListener('fetch', (event) => {
    const request = event.request;
    if (request.method !== 'GET') return;

    const url = new URL(request.url);
    const isSameOrigin = url.origin === self.location.origin;
    const isCdnLibrary = url.hostname === 'cdnjs.cloudflare.com';
    const isStatic = isSameOrigin || isCdnLibrary ||
        ['document', 'script', 'style', 'image', 'font'].includes(request.destination);

    if (isStatic) {
        event.respondWith(
            caches.match(request).then((cachedResponse) => {
                if (cachedResponse) return cachedResponse;

                return fetch(request).then((networkResponse) => {
                    if (networkResponse && (networkResponse.ok || networkResponse.type === 'opaque')) {
                        const copia = networkResponse.clone();
                        caches.open(CACHE_NAME).then((cache) => cache.put(request, copia));
                    }
                    return networkResponse;
                });
            })
        );
        return;
    }

    // Recursos dinamicos: rede primeiro; se estiver sem internet, usa cache.
    event.respondWith(
        fetch(request).catch(() => caches.match(request))
    );
});
